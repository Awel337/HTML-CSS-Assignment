# Per Scholas 2024 - RTT - 60

Name: Awel Alin
Email: awel.alin18@qmail.cuny.edu

# HTML and CSS Assignment

This is my attempt to build a website using HTML and CSS (no JavaScript)
The theme that this webiste is a Gym where you can Sign up to join.